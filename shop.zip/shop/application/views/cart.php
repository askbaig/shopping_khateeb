


    <div class="container nav-margin " ng-app="myApp" ng-controller="myCtrl">
      <div class="py-5 text-center">
        <h2>Checkout form</h2>
      </div>

      <div class="row">
        <div class="col-md-6 order-md-2 mb-6">
          <h4 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
          </h4>
          <ul class="list-group mb-3">
            <li class="list-group-item d-flex justify-content-between lh-condensed" ng-repeat="(key,val) in data.cart">
              <div>
                <h6 class="my-0">{{val.title}}</h6>
                <small class="text-muted" style="display: flex;margin-top: 10px;"><input class="form-control" ng-model="data.cart[key].quantity" ng-change="update_cart()"  style="width: 71px;height: 21px;margin-right: 10px;"> X {{val.price}}</small>
              </div>
              <span class="text-muted">${{val.quantity*val.price}}</span>
            </li>
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (USD)</span>
              <strong>${{get_cart_total()}}</strong>
            </li>
		  </ul>
		  
        </div>
        <div class="col-md-6 order-md-1">
          <h4 class="mb-3">Billing address</h4>
		  
		  <form class="needs-validation" >
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="firstName">First name</label>
                <input type="text" class="form-control" id="firstName" placeholder="" ng-model="data.first_name">
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Last name</label>
                <input type="text" class="form-control" id="lastName" placeholder=""  ng-model="data.last_name">
              </div>
            </div>

            

            <div class="mb-3">
              <label for="email">Email </label>
              <input type="email" class="form-control" id="email"  ng-model="data.email">
            </div>
			
			<div class="mb-3">
              <label for="mobile">Phone Number</label>
              <input type="text" class="form-control" id="mobile"  ng-model="data.mobile">
            </div>

            <div class="mb-3">
              <label for="address">Address</label>
              <input type="text" class="form-control" id="address"  ng-model="data.address">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>

            <div class="mb-3">
              <label for="address2">Address 2</label>
              <input type="text" class="form-control" id="address2"  ng-model="data.address1">
			</div>
			
			<div class="mb-3">
              <label for="address2">Pincode </label>
              <input type="text" class="form-control" id="picode" ng-model="data.pincode">
            </div>

           <hr>

            <h4 class="mb-3">Payment</h4>

            <div class="d-block my-3">
              <div class="custom-control custom-radio">
                <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" checked required>
                <label class="custom-control-label" for="credit">Cash on Delivery</label>
              </div>
             
            </div>
            <hr class="mb-4">
            <button ng-if="data.cart.length" class="btn btn-primary btn-lg btn-block" type="button" ng-click="checkout()">Continue to checkout</button>
          </form>
        </div>
      </div>

      <footer class="my-5 pt-5 text-muted text-center text-small">
        <p class="mb-1">&copy; 2017-2018 Company Name</p>
        <ul class="list-inline">
          <li class="list-inline-item"><a href="#">Privacy</a></li>
          <li class="list-inline-item"><a href="#">Terms</a></li>
          <li class="list-inline-item"><a href="#">Support</a></li>
        </ul>
      </footer>
    </div>

    
	<script>
		var app = angular.module('myApp', []);
		angular.module('myApp').filter('to_trusted', ['$sce', function($sce){
			return function(text) {
				return $sce.trustAsHtml(text);
			};
		}]);
		app.config(['$sceProvider', function($sceProvider) {
			$sceProvider.enabled(false);
		}]);

		app.controller('myCtrl', function($scope, $http) {
			$scope.data = {
				first_name:'',
				last_name:'',
				email:'',
				mobile:'',
				address:'',
				address1:'',
				pincode:'',
				cart : []
			};
            $scope.get_cart_total = function(){
				var price =0;
				angular.forEach($scope.data.cart, function (value, key) { 
					price += value.price*value.quantity;

				});
				return price;
			}
			$scope.get_carts= function(){
				$('.loader').show();
				var url = '<?php echo base_url();?>user/get_carts';
				$scope.data.rows= [];
				$http({
					method: 'GET', 
					url: url
                })
				.then(function(response) {
					$('.loader').hide();
					$scope.data.cart = response.data;
				});
			};
		

            $scope.update_cart= function(){
				$('.loader').show();
				var url = '<?php echo base_url();?>user/update_cart';
				$scope.data.rows= [];
				$http({
					method: 'POST', 
					url: url,
                    data : 'cart='+JSON.stringify($scope.data.cart),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        
                })
				.then(function(response) {
					$('.loader').hide();
					console.log(response.data);
            	});
			};

			$scope.checkout= function(){
				$('.loader').show();
				var url = '<?php echo base_url();?>user/checkout';
				var data = '';
				data += 'first_name='+$scope.data.first_name;
				data += '&last_name='+$scope.data.last_name;
				data += '&email='+$scope.data.email;
				data += '&mobile='+$scope.data.mobile;
				data += '&address='+$scope.data.address;
				data += '&address1='+$scope.data.address1;
				data += '&pincode='+$scope.data.pincode;
				data += '&cart='+JSON.stringify($scope.data.cart);
				$scope.data.rows= [];
				$http({
					method: 'POST', 
					url: url,
                    data : data,
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        
                })
				.then(function(response) {
					$('.loader').hide();
					console.log(response.data);
					location.href = '<?php echo base_url();?>success'
            	});
			};

			$scope.get_carts();
		});
		</script>
		