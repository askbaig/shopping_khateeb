


<div class="container nav-margin "  style="padding: 20px;" ng-app="myApp" ng-controller="myCtrl">
		<div class="card " style="padding: 20px;" >
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6" style="text-align: center;">
						
                <img  ng-src="{{data.image}}" style="max-height: 300px;
text-align: center;width:auto;"/>
                    
                </div>
                <div class="details col-md-6">
                    <h3 class="product-title">{{data.title}}</h3>

                    <h5 class="product-title">Category : {{data.category}}</h5>
                    
                    <p class="product-description mt-4">{{data.description}}</p>
                    
                    <h4 class="price mt-4">current price: <span>${{data.price}}</span></h4>
                    
                
                    <div class="action mt-5" style="display: flex;">
                        <input class="form-control" ng-model="quantity" type="number"  style="width: 100px;color: #000;margin-right:20px;">
                        <button class="btn btn-primary" ng-click="add_cart()" type="button">Add to cart</button>
                        <a  href="<?php echo base_url(); ?>"  class="btn btn-default" >Continue Shoping</a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 
<script>
		var app = angular.module('myApp', []);
		angular.module('myApp').filter('to_trusted', ['$sce', function($sce){
			return function(text) {
				return $sce.trustAsHtml(text);
			};
		}]);
		app.config(['$sceProvider', function($sceProvider) {
			$sceProvider.enabled(false);
		}]);

		app.controller('myCtrl', function($scope, $http) {
			$scope.data = {};
            $scope.product_id = '<?php echo $id; ?>';
            $scope.quantity = 1;
            
			$scope.get_product_data= function(){
				$('.loader').show();
				var url = 'https://fakestoreapi.com/products/'+$scope.product_id;
				$scope.data.rows= [];
				$http({
					method: 'GET', 
					url: url
                })
				.then(function(response) {
					$('.loader').hide();
					$scope.data = response.data;
				});
			};

            $scope.add_cart= function(){
				$('.loader').show();
				var url = '<?php echo base_url();?>user/add_cart';
				$scope.data.rows= [];
				$http({
					method: 'POST', 
					url: url,
                    data : 'product_id='+$scope.product_id+'&quantity='+$scope.quantity+'&price='+$scope.data.price+'&title='+$scope.data.title,
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                        
                })
				.then(function(response) {
					$('.loader').hide();
					console.log(response.data);
                    location.href = '<?php echo base_url();?>cart'
				});

			};

			$scope.get_product_data();
		});
		</script>
		



  