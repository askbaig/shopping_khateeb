<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	
    function __construct() {
        parent::__construct();

        if(!$this->session->userdata('shopguest')){
            $insert = array(
                'username'=>$this->randomString(10),
                'password'=>$this->randomString(10),
                'created'=>time(),
                'is_guest'=>1
            );
            $this->db->insert('users',$insert);
            $this->session->set_userdata('shopguest',$this->db->insert_id());
        }

        if($this->session->userdata('shopguest')){
            $this->user_id = $this->session->userdata('shopguest');
            $this->is_guest = 1;
        }
        if($this->session->userdata('shopuser')){
            $this->user_id = $this->session->userdata('shopuser');
            $this->is_guest = 0;
        }
        $this->data = array('user_id'=>$this->user_id,'is_guest'=>$this->is_guest );
    }

    public function index(){
        $this->load->view('header',$this->data);
        $this->load->view('listing');
        $this->load->view('footer');
        
    }
    public function details($id){
        $this->load->view('header',$this->data);
        $this->load->view('details',array('id'=>$id));
        $this->load->view('footer');
        
    }
    public function add_cart(){
        $product_id = $this->input->post('product_id');
        $quantity = $this->input->post('quantity');
        $title = $this->input->post('title');
        $price = $this->input->post('price');
        $user_id = $this->user_id;
     
        $data = array(
            'product_id'=>$product_id,
            'title'=>$title,
            'price'=>$price,
            'quantity'=>$quantity,
            'user_id'=>$user_id,
            'created'=>time()
        );
        if($this->db->insert('cart',$data)){
            echo 1;
        }
        else{
            echo 0;
        }
    }
    public function update_cart(){
        $cart = json_decode($this->input->post('cart'),true);
        $user_id = $this->user_id;
        
        $this->db->where('user_id',$user_id);
        $this->db->delete('cart');

        foreach($cart as $row){
            $data = array(
                'product_id'=>$row['product_id'],
                'title'=>$row['title'],
                'price'=>$row['price'],
                'quantity'=>$row['quantity'],
                'user_id'=>$user_id,
                'created'=>time()
            );
            $this->db->insert('cart',$data);
            
        }
       
    }
    public function checkout(){
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $mobile = $this->input->post('mobile');
        $address = $this->input->post('address');
        $address1 = $this->input->post('address1');
        $pincode = $this->input->post('pincode');
        $cart = $this->input->post('cart');
        $user_id = $this->user_id;


        $data = array(
            'first_name'=>$first_name,
            'last_name'=>$last_name,
            'email'=>$email,
            'mobile'=>$mobile,
            'address'=>$address,
            'address1'=>$address1,
            'pincode'=>$pincode,
            'cart'=>$cart,
            'user_id'=>$user_id,
            'created'=>time()
        );
        $this->db->insert('orders',$data);

        $this->db->where('user_id',$user_id);
        $this->db->delete('cart');



    }
    public function success_page(){
        $this->load->view('header',$this->data);
        $this->load->view('success');
        $this->load->view('footer');
    }
    public function cart(){
        $this->load->view('header',$this->data);
        $this->load->view('cart');
        $this->load->view('footer');
    }
    
    public function get_carts(){
        $this->db->where('user_id',$this->user_id);
        $query = $this->db->get('cart');
        echo json_encode($query->result_array());
    }
    

    public function login(){
        if( $this->session->userdata('shopuser') ){
			redirect(base_url());
        }
        

        $msg = '';
        if($this->input->post('login')){
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            $query = $this->db->get_where('users',array('username'=>$username,'password'=>$password,'is_guest'=>0));
            if($query->num_rows()){
                $row  = $query->row_array();
                $this->session->set_userdata('shopuser', $row['id']);
                redirect(base_url());
            }

        }
        $this->load->view('login',array('msg'=>$msg));
		
    }

    public function signup(){
        if( $this->session->userdata('shopuser') ){
			redirect(base_url());
        }
        

        $msg = '';
        if($this->input->post('signup')){
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));
            
           

            $query = $this->db->get_where('users',array('username'=>$username,'is_guest'=>0));
            if(!$query->num_rows()){
                $insert = array(
                    'username'=>$username,
                    'password'=>$password,
                    'first_name'=>$first_name,
                    'last_name'=>$last_name,
                    'is_guest'=>0,
                    'created'=>time(),
                );
                $this->db->insert('users',$insert);
                $this->session->set_userdata('shopuser',$this->db->insert_id());
                redirect(base_url());
            }

        }
        $this->load->view('signup',array('msg'=>$msg));
		
    }

    public function logout(){
        $this->session->unset_userdata('shopuser');
        redirect(base_url().'login');
    }
    public function randomString($length = 10) {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }


    
  
}