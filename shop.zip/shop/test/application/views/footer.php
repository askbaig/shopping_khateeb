
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
	

	<footer class="my-3 pt-3 text-muted text-center text-small">
        <p class="mb-1">© 2020-2020 Company Name</p>
    </footer>
</body>
</html>


