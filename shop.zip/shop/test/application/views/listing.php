
	<main class="nav-margin" role="main" ng-app="myApp" ng-controller="myCtrl">

      <div class="album py-5 bg-light">
        <div class="container">
			
			  
			<div class="row" >
				<div class="col-md-4" ng-repeat="(key,val) in data.rows">
					<div class="card mb-4 box-shadow" >
						<a href="<?php echo base_url().'view/'; ?>{{val.id}}" style="text-decoration: none;color: unset;text-align: center;">
						<img class="card-img-top" ng-src="{{val.image}}" alt="{{val.title}}" style="height: 200px;width: auto;max-width: 250px;">
						<div class="card-body">
							<h4>$ {{val.price}}</h4>
							<p>
								{{val.title}}
							</p>
							
						</div>
						</a>
					</div>
				</div>
			  </div>
		 


        </div>
      </div>

    </main>

    
	<script>
		var app = angular.module('myApp', []);
		angular.module('myApp').filter('to_trusted', ['$sce', function($sce){
			return function(text) {
				return $sce.trustAsHtml(text);
			};
		}]);
		app.config(['$sceProvider', function($sceProvider) {
			$sceProvider.enabled(false);
		}]);

		app.controller('myCtrl', function($scope, $http) {
			$scope.data = {
				limit:9,
				total :0,
				page:1,
				rows:[]
				
			};
			
			$scope.get_product_data= function(){
				$('.loader').show();
				var url = 'https://fakestoreapi.com/products';
				$scope.data.rows= [];
				$http({
					method: 'GET', 
					url: url, 
					 headers: {'Accept': 'application/json; api_version=2'}
				})
				.then(function(response) {
					$('.loader').hide();
					$scope.data.rows = response.data;
				});

			};

			$scope.get_product_data();
		});
		</script>
		


