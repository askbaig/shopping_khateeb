<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon.ico">
    <title>Product Listing</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
    <script>window.jQuery || document.write('<script src="https://getbootstrap.com/docs/4.0/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="https://getbootstrap.com/docs/4.0/assets/js/vendor/popper.min.js"></script>
    <script src="https://getbootstrap.com/docs/4.0/dist/js/bootstrap.min.js"></script>
	<script src="https://getbootstrap.com/docs/4.0/assets/js/vendor/holder.min.js"></script>
	<style>
		.nav-margin{
			margin-top: 54px;
		}
		[ng\:cloak], [ng-cloak], .ng-cloak {
			display: none !important;
		}
	</style>
	
		<style>
		.lds-ring {
		display: inline-block;
		position: relative;
		width: 80px;
		height: 80px;
		left: calc(50% - 40px );
		top: calc(50% - 40px );
		}
		.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 64px;
		height: 64px;
		margin: 8px;
		border: 8px solid #fff;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: #000 transparent transparent transparent;
		}
		.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
		}
		.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
		}
		.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
		}
		@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
		}
		.loader{
			display: none;
		}
		
	</style>
  
  </head>

  <body >

	<div class="loader" style="position: fixed;width: 100%;height: 100%;background: rgba(255, 255, 255,.5);z-index:100;"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div>
	
	<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="<?php echo base_url(); ?>">Shoping Site</a>
	  
	  <a href="<?php echo base_url(); ?>cart"  class="ml-md-auto d-md-flex btn btn-primary">Cart</a>

	  <?php if(!$is_guest){ ?>
	  <a href="<?php echo base_url(); ?>logout" class="btn btn-info" style="margin-left:20px;">Logout</a>
	  <?php } else { ?>
		<a href="<?php echo base_url(); ?>login" class="btn btn-info" style="margin-left:20px;">Login</a>
	  <?php }  ?>
	</nav>
	



